# Release Notes for AfterPay

## v0.0.1

### Added
[Further information](https://developers.plentymarkets.com/marketplace/plugin-requirements#marketplace-changelog)