# Release Notes für AfterPay

## v0.0.1

### Hinzugefügt
[Weitere Informationen](https://developers.plentymarkets.com/marketplace/plugin-requirements#marketplace-changelog)