# Generated plugin

[Further information](https://developers.plentymarkets.com/marketplace/plugin-requirements#marketplace-user-guide)